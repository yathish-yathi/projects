package com.SpringData.JCO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
